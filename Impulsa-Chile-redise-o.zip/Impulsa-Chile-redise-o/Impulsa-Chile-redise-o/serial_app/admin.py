from django.contrib import admin
from serial_app.models import Student
# Register your models here.
